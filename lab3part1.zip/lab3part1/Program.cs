﻿namespace lab3Abstract
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //dog name ask 
            Console.WriteLine("Enter dog name: ");
            string dogName = Console.ReadLine();

            Console.WriteLine("Enter dog color: ");
            string dogColor = Console.ReadLine();

            Console.WriteLine("Enter dog age: ");
            string dogAge = Console.ReadLine();
            int newDogAge = int.Parse(dogAge);

            //new dog object 
            Dog newDog = new Dog(
                dogName, dogColor, newDogAge
                );
            Console.WriteLine("Dog Name: " + newDog.name);
            Console.WriteLine("Dog Color: " + newDog.color);
            Console.WriteLine("Dog Age: " + newDog.age);
            //eat method 
            newDog.Eat();



            //CAT PART 
            Console.WriteLine("Enter cat name: ");
            string catName = Console.ReadLine();

            Console.WriteLine("Enter cat color: ");
            string catColor = Console.ReadLine();

            Console.WriteLine("Enter cat age: ");
            string catAge = Console.ReadLine();
            int newCatAge = int.Parse(catAge);

            Cat newCat = new Cat(
                catName, catColor, newCatAge
                );
            Console.WriteLine("Dog Name: " + newCat.name);
            Console.WriteLine("Dog Color: " + newCat.color);
            Console.WriteLine("Dog Age: " + newCat.age);
            //eat method 
            newCat.Eat();

        }
    }
}