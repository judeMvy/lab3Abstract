﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3Abstract
{
    abstract class Animal
    {
        public string name {get; set; }
        public string color { get; set; }
        public int age {  get; set; }

        public Animal(string name, string color, int age)
        { 
            this.name = name;
            this.color = color;
            this.age = age; 

        }
        //method called Eat that is an abstract method of type void.
        public abstract void Eat();
    }
}
