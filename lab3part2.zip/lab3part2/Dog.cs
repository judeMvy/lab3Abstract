﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3part2
{
    internal class Dog : IAnimal
    {
        public Dog(string name, string color, int height, int age) : base(name, color, height, age)
        {

        }

        public override void Eat()
        {
            Console.WriteLine("Dogs eat meat.");
        }
        public override string Cry()
        {
            Console.WriteLine("Woof!");
            return "Woof!";

        }
    }
}
