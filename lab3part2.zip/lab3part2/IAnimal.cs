﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3part2
{
    abstract class IAnimal
    {
        public string name { get; set; }
        public string color { get; set; }
        public int height { get; set; }
        public int age { get; set; }

        public IAnimal(string name, string color, int height, int age)
        {
            this.name = name;
            this.color = color;
            this.height = height;
            this.age = age;

        }

        public abstract void Eat();
        public abstract string Cry();
    
    }
}
