﻿namespace lab3part2
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
            //DOG PART 
            Console.WriteLine("Enter dog name: ");
            string dogName = Console.ReadLine();

            Console.WriteLine("Enter dog color: ");
            string dogColor = Console.ReadLine();

            Console.WriteLine("Enter dog height: ");
            string dogHeight = Console.ReadLine();
            int newDogHeigt = int.Parse(dogHeight);    

            Console.WriteLine("Enter dog age: ");
            string dogAge = Console.ReadLine();
            int newDogAge = int.Parse(dogAge);

            Dog newDog = new Dog(dogName, dogColor, newDogHeigt, newDogAge);

            Console.WriteLine($"Dog Name: {newDog.name}");
            Console.WriteLine($"Dog Height: {newDog.height} cm");
            Console.WriteLine($"Dog Color: {newDog.color}");
            Console.WriteLine($"Dog Age: {newDog.age} years");

            newDog.Eat();
            newDog.Cry();

            //CAT PART 
            Console.WriteLine("Enter cat name: ");
            string catName = Console.ReadLine();

            Console.WriteLine("Enter cat color: ");
            string catColor = Console.ReadLine();

            Console.WriteLine("Enter cat height: ");
            string catHeight = Console.ReadLine();
            int newCatHeight = int.Parse(catHeight);

            Console.WriteLine("Enter cat age: ");
            string catAge = Console.ReadLine();
            int newCatAge = int.Parse(catAge);

            Cat newCat = new Cat(
                catName, catColor, newCatHeight, newCatAge
                );
            Console.WriteLine("Dog Name: " + newCat.name);
            Console.WriteLine("Dog Color: " + newCat.color);
            Console.WriteLine("Dog Height: " + newCat.height);
            Console.WriteLine("Dog Age: " + newCat.age);
           
            newCat.Eat();
            newCat.Cry();

            //create list 
            List<IAnimal> animals = new List<IAnimal>
            {
                newDog,
                newCat,
            };
            Console.WriteLine("Name of all animals: ");
            foreach (IAnimal animal in animals)
            {
                Console.WriteLine($"{animal.name}");
            }









        }
    }
}